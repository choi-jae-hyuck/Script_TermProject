from distutils.core import setup

setup(name='Script_Tour',
      version='1.0',
      py_modules=['main']
      )
